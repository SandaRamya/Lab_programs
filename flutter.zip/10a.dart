import 'dart:convert';
import 'package:http/http.dart'as http;

void main() async {
  final url ='https://jsonplaceholder.typicode.com/posts';
  final response=await http.get(Uri.parse(url));
  if(response.statusCode==200) {
    List<dynamic>data=jsonDecode(response.body);
    for(var item in data) {
      print('Tile:${item['title']}');
      print('Body:${item['body']}');
      print('__');
    }
  }else {
    print('Failed to load data:${response.statusCode}');
  }
}

